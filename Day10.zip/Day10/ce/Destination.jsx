
import React from 'react'
const Destination = () => {
 return (
 <div>Destination</div>
 )
}
export default Destination;
