
import React from 'react';
const Home = () => {
 return (
 <div>
 <h2>Welcome to Music World</h2>
 </div>
 );
};
export default Home;
